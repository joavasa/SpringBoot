package com.EjercicioPalindromo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjercicioPalindromoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjercicioPalindromoApplication.class, args);
	}

}
